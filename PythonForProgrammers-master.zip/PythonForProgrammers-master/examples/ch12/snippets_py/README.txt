Sections 12.7-11 use one continuous IPython session, so all of these are in one
snippet file.
